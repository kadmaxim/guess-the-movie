-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Янв 14 2018 г., 01:00
-- Версия сервера: 5.5.25
-- Версия PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `augsburg`
--

-- --------------------------------------------------------

--
-- Структура таблицы `gamers`
--

CREATE TABLE IF NOT EXISTS `gamers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `score` int(10) NOT NULL DEFAULT '0',
  `mode` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Дамп данных таблицы `gamers`
--

INSERT INTO `gamers` (`id`, `name`, `score`, `mode`) VALUES
(14, 'Mr. Pitt', 4, 0),
(17, 'bestone', 10, 0),
(18, 'Max', 21, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `movies`
--

CREATE TABLE IF NOT EXISTS `movies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=37 ;

--
-- Дамп данных таблицы `movies`
--

INSERT INTO `movies` (`id`, `title`, `img`) VALUES
(1, 'The Shawshank Redemption', 'https://www.hs-augsburg.de/~kadmax/na/C4rJQz.jpg'),
(2, 'The Green Mile', 'https://www.hs-augsburg.de/~kadmax/na/Zd6yBs.jpg'),
(3, 'Forrest Gump', 'https://www.hs-augsburg.de/~kadmax/na/Hev3DD.jpg'),
(4, 'Schindler''s List', 'https://www.hs-augsburg.de/~kadmax/na/F74Em8.jpg'),
(5, 'Inception', 'https://www.hs-augsburg.de/~kadmax/na/2q5Js6.jpg'),
(6, 'Intouchables', 'https://www.hs-augsburg.de/~kadmax/na/7rt3BD.jpg'),
(7, 'The Lion King', 'https://www.hs-augsburg.de/~kadmax/na/3eLAud.jpg'),
(9, 'Léon', 'https://www.hs-augsburg.de/~kadmax/na/3U7sFM.jpg'),
(10, 'Fight Club', 'https://www.hs-augsburg.de/~kadmax/na/kQa8TY.jpg'),
(11, 'Knockin'' on Heaven''s Door', 'https://www.hs-augsburg.de/~kadmax/na/atT52D.jpg'),
(12, 'Pulp Fiction', 'https://www.hs-augsburg.de/~kadmax/na/f2ZuTR.jpg'),
(13, 'Interstellar', 'https://www.hs-augsburg.de/~kadmax/na/r2anW4.jpg'),
(14, 'Gladiator', 'https://www.hs-augsburg.de/~kadmax/na/C8vNqH.jpg'),
(15, 'Back to the Future', 'https://www.hs-augsburg.de/~kadmax/na/n2MMxM.jpg'),
(16, 'Lock, Stock and Two Smoking Barrels', 'https://www.hs-augsburg.de/~kadmax/na/RB3x4R.jpg'),
(17, 'The Lord of the Rings', 'https://www.hs-augsburg.de/~kadmax/na/F74EmB.jpg'),
(18, 'The Matrix', 'https://www.hs-augsburg.de/~kadmax/na/av5RYR.jpg'),
(19, 'WALL·E', 'https://www.hs-augsburg.de/~kadmax/na/6XVrHq.jpg'),
(20, 'RocknRolla', 'https://www.hs-augsburg.de/~kadmax/na/ER6m6a.jpg'),
(21, 'Yes Man', 'https://www.hs-augsburg.de/~kadmax/na/EmyS4y.jpg'),
(22, 'The Boat That Rocked', 'https://www.hs-augsburg.de/~kadmax/na/2x8AFE.jpg'),
(25, 'Sherlock Holmes', 'https://www.hs-augsburg.de/~kadmax/na/f4.jpg'),
(26, 'Up', 'https://www.hs-augsburg.de/~kadmax/na/qw1.jpg'),
(27, 'Avatar', 'https://www.hs-augsburg.de/~kadmax/na/d1.jpg'),
(28, 'Inglourious Basterds', 'https://www.hs-augsburg.de/~kadmax/na/e3.jpg'),
(29, 'The Hangover', 'https://www.hs-augsburg.de/~kadmax/na/we1w.jpg'),
(30, 'District 9', 'https://www.hs-augsburg.de/~kadmax/na/a2.jpg'),
(31, 'Star Trek', 'https://www.hs-augsburg.de/~kadmax/na/1ds.jpg'),
(33, 'Rise of the Guardians', 'https://www.hs-augsburg.de/~kadmax/na/ww13.jpg'),
(34, 'Wreck-It Ralph', 'https://www.hs-augsburg.de/~kadmax/na/op1.jpg'),
(35, 'The Avengers', 'https://www.hs-augsburg.de/~kadmax/na/uz2.jpg'),
(36, 'Inside Out', 'https://www.hs-augsburg.de/~kadmax/na/eq1.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `password`) VALUES
(1, 'admin', '81dc9bdb52d04dc20036dbd8313ed055');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
